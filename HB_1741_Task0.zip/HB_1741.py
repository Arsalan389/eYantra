#!/usr/bin/env python3

'''
*****************************************************************************************
*
*        		===============================================
*           		    HolA Bot (HB) Theme (eYRC 2022-23)
*        		===============================================
*
*  This script should be used to implement Task 0 of HolA Bot (KB) Theme (eYRC 2022-23).
*
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*
*****************************************************************************************
'''

# Team ID:			[ Team-ID ]
# Author List:		[ Names of team members worked on this file separated by Comma: Name1, Name2, ... ]
# Filename:			task_0.py
# Functions:
# 					[ Comma separated list of functions in this file ]
# Nodes:		    Add your publishing and subscribing node


####################### IMPORT MODULES #######################
import sys
import traceback
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
##############################################################

	
def callback(data):

    """
	Purpose:
	---
	This function should be used as a callback. Refer Example #1: Pub-Sub with Custom Message in the Learning Resources Section of the Learning Resources.
    You can write your logic here.
    NOTE: Radius value should be 1. Refer expected output in document and make sure that the turtle traces "same" path.

	Input Arguments:
	---
        `data`  : []
            data received by the call back function

	Returns:
	---
        May vary depending on your logic.

	Example call:
	---
        Depends on the usage of the function.
	"""

    global ipose, vel,_exit

    if ipose.x == 0 :
        ipose = data
        vel.linear.x =0.5
        vel.angular.z=0.5

    if round(data.theta,2) == 3.14 :
        
        vel.linear.x =0
        vel.angular.z = 0.5

    if round(data.theta,2) == -1.57 :

        vel.angular.z =0

        if round(ipose.y,3) == round(data.y,3):
            vel.linear.x = 0
            
        else:
            vel.linear.x = 1



def main():
    """
	Purpose:
	---
	This function will be called by the default main function given below.
    You can write your logic here.

	Input Arguments:
	---
        None

	Returns:
	---
        None

	Example call:
	---
        main()
	"""

    rospy.init_node('turtlesim',anonymous=True)
    pub = rospy.Publisher('turtle1/cmd_vel',Twist,queue_size=10)

    rospy.Subscriber('turtle1/pose',Pose,callback)
    

    while not rospy.is_shutdown():

        pub.publish(vel)

        if ipose.x !=0 and vel.angular.z ==0 and vel.linear.x ==0:
            pub.publish(vel)
            break
        

################# ADD GLOBAL VARIABLES HERE #################

vel = Twist()
ipose = Pose()

##############################################################


################# ADD UTILITY FUNCTIONS HERE #################



##############################################################


######### YOU ARE NOT ALLOWED TO MAKE CHANGES TO THIS PART #########
if __name__ == "__main__":
    try:
        print("------------------------------------------")
        print("         Python Script Started!!          ")
        print("------------------------------------------")
        main()

    except:
        print("------------------------------------------")
        traceback.print_exc(file=sys.stdout)
        print("------------------------------------------")
        sys.exit()

    finally:
        print("------------------------------------------")
        print("    Python Script Executed Successfully   ")
        print("------------------------------------------")
