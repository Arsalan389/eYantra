#!/usr/bin/env python3

#importing th required libraries
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import sin,cos,pi
from tf.transformations import euler_from_quaternion

#initialising variables for global pose
hola_x = 0
hola_y = 0
hola_theta = 0

#callback functiont to get odom data
def odometryCb(msg):
	global hola_x, hola_y, hola_theta

	hola_x = msg.pose.pose.position.x
	hola_y = msg.pose.pose.position.y

	#quaternion for pose
	rot_q = msg.pose.pose.orientation
	#orientation along z from euler transform on quaternion
	(roll, pitch, hola_theta) = euler_from_quaternion([rot_q.x,rot_q.y,rot_q.z,rot_q.w])

def main():
	#initializing controller.py node
	rospy.init_node ("controller")
	#setting up odom subscriber
	sub = rospy.Subscriber("/odom", Odometry, odometryCb)
	#setting up cmd vel publisher
	pub = rospy.Publisher("/cmd_vel",Twist, queue_size=1)
	#twist message for bot velocity
	vel = Twist()	
	rate = rospy.Rate(10)
	#defining desired pose
	x_d=1
	y_d=1
	theta_d=pi/4
	while not rospy.is_shutdown():
		#global error
		g_err_x = x_d - hola_x
		g_err_y = y_d - hola_y

		#robot frame error
		r_x_err=(g_err_x*cos(hola_theta)) + (g_err_y*sin(hola_theta))
		r_y_err=(g_err_y*cos(hola_theta)) - (g_err_x*sin(hola_theta))
		#global and robot frame error remains the same
		err_theta = theta_d - hola_theta


		vel.linear.x = r_x_err*2
		vel.linear.y = r_y_err*2
		vel.angular.z = err_theta*5

		pub.publish(vel)
		rate.sleep()

		vel.linear.x = 0
		vel.linear.y = 0
		vel.angular.z = 0

		pub.publish(vel)
		rate.sleep()
				

if __name__ == "__main__":
	try:
		main()
	except rospy.ROSInterruptException:
		pass